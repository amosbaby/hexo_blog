<?php

// Heading
$_['heading_title']    = '奖励积分';

// Text
$_['text_total']       = '订单总计';
$_['text_success']     = '成功: 已修改奖励积分！';
$_['text_edit']        = '编辑奖励积分';

// Entry
$_['entry_status']     = '状态';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告: 无权限修改奖励积分！';