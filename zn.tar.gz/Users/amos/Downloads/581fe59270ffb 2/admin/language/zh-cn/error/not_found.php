<?php

// Heading
$_['heading_title']  = '找不到此页面！';

// Text
$_['text_not_found'] = '找不到此页面！如果该问题一直存在，请联系网站管理员。';