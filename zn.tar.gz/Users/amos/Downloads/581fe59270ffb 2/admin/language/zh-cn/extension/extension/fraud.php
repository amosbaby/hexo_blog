<?php
// Heading
$_['heading_title']    = '防欺诈';

// Text
$_['text_success']     = '成功: 已修改防欺诈部分！';
$_['text_list']        = '防欺诈列表';

// Column
$_['column_name']      = '防欺诈名称';
$_['column_status']    = '状态';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 无权限修改防欺诈！';