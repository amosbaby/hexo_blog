<?php
// Heading
$_['heading_title']  = '扩充功能';

// Text
$_['text_success']   = '成功: 已修改扩充功能！';
$_['text_list']      = '扩充功能列表';
$_['text_type']      = '选择扩充功能类型';
$_['text_filter']    = '筛选';
$_['text_analytics'] = '谷歌分析';
$_['text_captcha']   = '验证码';
$_['text_dashboard'] = '仪表盘';
$_['text_feed']      = '输出共享';
$_['text_fraud']     = '反欺诈';
$_['text_module']    = '模组';
$_['text_content']   = '内容模组';
$_['text_menu']      = '菜单模组';
$_['text_payment']   = '支付';
$_['text_shipping']  = '配送';
$_['text_theme']     = '模板主题';
$_['text_total']     = '订单项';