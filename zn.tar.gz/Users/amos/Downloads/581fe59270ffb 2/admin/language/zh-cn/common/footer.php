<?php

// Text
$_['text_footer'] 	= '<a href="http://www.opencartchina.com">OpenCartChina</a> &copy; 2015-' . date('Y') . ' 版权所有。';
$_['text_version'] 	= '版本号 %s';
