<?php

// Heading
$_['heading_title'] = '总订单数量';

// Text
$_['text_view']     = '查看更多......';