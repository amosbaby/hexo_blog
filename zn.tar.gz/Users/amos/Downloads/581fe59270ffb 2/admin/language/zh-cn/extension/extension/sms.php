<?php

// Heading
$_['heading_title']     = '手机短信接口';

// Text
$_['text_success']      = '成功: 已修改手机短信接口！';
$_['text_list']         = '手机短信接口列表';

// Column
$_['column_name']       = '手机短信接口';
$_['column_status']     = '状态';
$_['column_sort_order'] = '排序';
$_['column_action']     = '操作';

// Error
$_['error_permission']  = '警告: 无权限修改手机短信接口！';