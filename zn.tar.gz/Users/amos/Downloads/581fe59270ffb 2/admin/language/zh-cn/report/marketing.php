<?php

// Heading
$_['heading_title']    = '市场推广统计报告';

// Text
$_['text_list']         = '市场推广列表';
$_['text_all_status']   = '所有状态';

// Column
$_['column_campaign']  = '活动名称';
$_['column_code']      = '代码';
$_['column_clicks']    = '点击量';
$_['column_orders']    = '订单数量';
$_['column_total']     = '总计';

// Entry
$_['entry_date_start'] = '开始日期';
$_['entry_date_end']   = '结束日期';
$_['entry_status']     = '订单状态';