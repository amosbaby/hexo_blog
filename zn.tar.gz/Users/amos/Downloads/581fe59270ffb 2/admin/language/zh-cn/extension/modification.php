<?php
// Heading
$_['heading_title']     = '代码调整';

// Text
$_['text_success']      = '成功: 已修改代码调整！';
$_['text_refresh']      = '任何时候想启用/禁用或删除代码调整，只需要点击刷新按钮来重建代码调整缓存！';
$_['text_list']         = '代码调整列表';

// Column
$_['column_name']       = '代码调整名称';
$_['column_author']     = '作者';
$_['column_version']    = '版本';
$_['column_status']     = '状态';
$_['column_date_added'] = '添加日期';
$_['column_action']     = '操作';

// Error
$_['error_permission']  = '警告: 无权限修改代码调整！';