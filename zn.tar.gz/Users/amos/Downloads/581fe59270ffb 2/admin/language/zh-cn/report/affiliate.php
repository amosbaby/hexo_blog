<?php

// Heading
$_['heading_title']     = '推广会员佣金统计报告';

// Text
$_['text_list']         = '推广会员佣金列表';

// Column
$_['column_affiliate']  = '推广会员姓名';
$_['column_email']      = 'E-Mail';
$_['column_status']     = '状态';
$_['column_commission'] = '佣金';
$_['column_orders']     = '订单数量';
$_['column_total']      = '总计';
$_['column_action']     = '操作';

// Entry
$_['entry_date_start']  = '开始日期';
$_['entry_date_end']    = '结束日期';