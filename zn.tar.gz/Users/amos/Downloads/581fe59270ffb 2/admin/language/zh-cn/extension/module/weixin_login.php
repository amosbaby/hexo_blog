<?php

// Heading
$_['heading_title']        		= '微信账号登录';

//Text
$_['text_module']          		= '模组';
$_['text_success']         		= '成功: 已修改微信账号登录模组！';
$_['text_edit']            		= '编辑微信账号登录 模组';
$_['text_weixin_open_signup']   = '在未成功开通微信开发者账号并绑定此公司微信公众号情况下，请勿启用本模组功能。相关设置请参考MyCnCart官网(http://www.mycncart.com)相关手册教程文章。';

//Entry
$_['entry_appid']         		= 'AppID';
$_['entry_appsecret']         	= 'AppSecret';
$_['entry_status']         		= '状态';

//Error
$_['error_permission']     		= '警告: 无权限修改 微信账号登录模组！';
